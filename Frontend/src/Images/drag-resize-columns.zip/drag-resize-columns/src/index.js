import ResizableColumns from './class';
import adapter from './adapter';

export default ResizableColumns;